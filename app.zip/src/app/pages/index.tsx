import Head from 'next/head';
import BalanceDisplay from '../app/components/BalanceDisplay';
import QRCodeScanner from '../../components/QRCodeScanner';

const HomePage = () => {
  const [address, setAddress] = useState<string>('');

  const handleScan = (address: string) => {
    setAddress(address);
  };

  return (
    <div>
      <Head>
        <title>Ethereum Balance Checker</title>
      </Head>
      <QRCodeScanner onScan={handleScan} />
      {address && <BalanceDisplay address={address} />}
    </div>
  );
};

export default HomePage;
function useState<T>(arg0: string): [any, any] {
    throw new Error('Function not implemented.');
}

