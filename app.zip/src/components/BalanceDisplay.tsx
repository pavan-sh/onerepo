import { useState, useEffect, SetStateAction } from 'react';
import { getBalance } from '../utils/ethers';
import QRCodeScanner from './QRCodeScanner';

interface BalanceDisplayProps {
  address: string;
}

const BalanceDisplay: React.FC<BalanceDisplayProps> = ({ address }) => {
  const [balance, setBalance] = useState<string>('0');

  useEffect(() => {
    getBalance(address).then((balance: SetStateAction<string>) => setBalance(balance));
  }, [address]);

  return <div>Balance: {balance}</div>;
};

export default BalanceDisplay;


