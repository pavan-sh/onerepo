import React from 'react';

const NavigationBar = () => {
  return (
    <div>
      <ul>
        <li>
          <a href="/">Balance</a>
        </li>
        <li>
          <a href="/about">About</a>
        </li>
      </ul>
    </div>
  );
};

export default NavigationBar;
