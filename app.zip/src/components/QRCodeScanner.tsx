import { useState } from 'react';
import { QRCodeScanner } from 'react-qr-reader';

interface QRCodeScannerProps {
  onScan: (address: string) => void;
}

const QRCodeScanner: React.FC<QRCodeScannerProps> = ({ onScan }) => {
  const [address, setAddress] = useState<string>('');

  const handleScan = (address: string) => {
    onScan(address);
  };

  return <QRCodeScanner onScan={handleScan} />;
};

export default QRCodeScanner;
