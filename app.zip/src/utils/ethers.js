import { ethers } from 'ethers';

const getBalance = async (address: string) => {
  const provider = new ethers.providers.JsonRpcProvider();
  const balance = await provider.getBalance(address);
  return ethers.utils.formatEther(balance);
};

export { getBalance };
